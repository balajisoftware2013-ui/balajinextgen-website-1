/**
 * BALAJI NEXTGEN ERP — AI ASSISTANT v2.0
 * Embedded AI Chat Widget — works on ALL dashboard pages
 * Uses Anthropic Claude via GAS proxy OR direct API
 */

(function() {
  'use strict';

  // Inject AI Assistant styles
  const style = document.createElement('style');
  style.textContent = `
    #bnj-ai-btn {
      position:fixed;bottom:24px;right:24px;width:56px;height:56px;
      background:linear-gradient(135deg,#1e3a8a,#3b82f6);
      border-radius:50%;border:none;cursor:pointer;box-shadow:0 4px 20px rgba(37,99,235,.5);
      display:flex;align-items:center;justify-content:center;font-size:24px;
      z-index:9999;transition:.3s;color:#fff;
    }
    #bnj-ai-btn:hover{transform:scale(1.1);}
    #bnj-ai-panel {
      position:fixed;bottom:90px;right:24px;width:380px;
      background:#fff;border-radius:20px;
      box-shadow:0 20px 60px rgba(0,0,0,.2);
      z-index:9999;display:none;flex-direction:column;
      max-height:520px;overflow:hidden;
      font-family:'Segoe UI',sans-serif;
    }
    #bnj-ai-panel.open{display:flex;}
    .bnj-ai-header {
      background:linear-gradient(135deg,#0f172a,#1e3a8a);color:#fff;
      padding:16px 20px;display:flex;justify-content:space-between;align-items:center;
      border-radius:20px 20px 0 0;
    }
    .bnj-ai-header h4{font-size:15px;font-weight:700;margin:0;}
    .bnj-ai-header span{font-size:11px;opacity:.7;margin-top:2px;display:block;}
    .bnj-ai-close{background:rgba(255,255,255,.2);border:none;color:#fff;
      width:28px;height:28px;border-radius:8px;cursor:pointer;font-size:16px;}
    .bnj-ai-msgs{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;min-height:200px;max-height:320px;}
    .bnj-msg{max-width:85%;padding:10px 14px;border-radius:14px;font-size:13px;line-height:1.5;}
    .bnj-user{background:#1e3a8a;color:#fff;align-self:flex-end;border-radius:14px 14px 4px 14px;}
    .bnj-bot{background:#f1f5f9;color:#1e293b;align-self:flex-start;border-radius:14px 14px 14px 4px;}
    .bnj-bot.thinking{opacity:.6;font-style:italic;}
    .bnj-ai-input{padding:12px 16px;border-top:1px solid #f1f5f9;display:flex;gap:8px;}
    .bnj-ai-input input{flex:1;padding:10px 14px;border:1px solid #e2e8f0;border-radius:10px;
      font-size:13px;outline:none;font-family:'Segoe UI',sans-serif;}
    .bnj-ai-input button{padding:10px 16px;background:#1e3a8a;color:#fff;border:none;
      border-radius:10px;cursor:pointer;font-size:13px;font-weight:600;}
    .bnj-quick{display:flex;flex-wrap:wrap;gap:6px;padding:10px 16px 0;}
    .bnj-chip{padding:5px 10px;background:#eff6ff;color:#1e40af;border-radius:8px;
      font-size:11px;cursor:pointer;border:1px solid #bfdbfe;font-weight:600;}
    .bnj-chip:hover{background:#dbeafe;}
    @media(max-width:480px){#bnj-ai-panel{width:calc(100vw - 32px);right:16px;}}
  `;
  document.head.appendChild(style);

  // Get current page context
  function getContext() {
    const user = typeof ERP !== 'undefined' ? ERP.getUser() : {};
    const page = window.location.pathname.split('/').pop().replace('.html','');
    const company = user ? (user.COMPANY_NAME || 'Balaji NextGen') : 'Balaji NextGen';
    return { page, company, role: user ? user.ROLE : 'USER', user };
  }

  // Inject HTML
  document.body.insertAdjacentHTML('beforeend', `
    <button id="bnj-ai-btn" title="AI Assistant" onclick="toggleAI()">🤖</button>
    <div id="bnj-ai-panel">
      <div class="bnj-ai-header">
        <div><h4>🤖 Balaji AI Assistant</h4><span id="bnj-ai-ctx">ERP Intelligence Engine</span></div>
        <button class="bnj-ai-close" onclick="toggleAI()">✕</button>
      </div>
      <div class="bnj-quick" id="bnj-chips">
        <div class="bnj-chip" onclick="askAI('Today sales summary')">📊 Sales</div>
        <div class="bnj-chip" onclick="askAI('Show pending KOTs')">🍽 KOT</div>
        <div class="bnj-chip" onclick="askAI('Low stock items')">📦 Stock</div>
        <div class="bnj-chip" onclick="askAI('Export Tally XML')">🧮 Tally</div>
        <div class="bnj-chip" onclick="askAI('Send WhatsApp invoice')">💬 WhatsApp</div>
        <div class="bnj-chip" onclick="askAI('GST summary this month')">📋 GST</div>
      </div>
      <div class="bnj-ai-msgs" id="bnj-msgs">
        <div class="bnj-msg bnj-bot">👋 Hello! I'm your Balaji ERP AI Assistant. I can help with sales reports, inventory, GST, Tally export, WhatsApp, and more. What do you need?</div>
      </div>
      <div class="bnj-ai-input">
        <input id="bnj-input" placeholder="Ask anything about your ERP..." onkeydown="if(event.key==='Enter')sendAI()">
        <button onclick="sendAI()">Send</button>
      </div>
    </div>
  `);

  // Update context
  const ctx = getContext();
  const ctxEl = document.getElementById('bnj-ai-ctx');
  if (ctxEl) ctxEl.textContent = ctx.company + ' · ' + ctx.page;

  window.toggleAI = function() {
    document.getElementById('bnj-ai-panel').classList.toggle('open');
  };

  window.askAI = function(q) {
    document.getElementById('bnj-input').value = q;
    sendAI();
  };

  window.sendAI = async function() {
    const input = document.getElementById('bnj-input');
    const q = input.value.trim();
    if (!q) return;
    input.value = '';

    addMsg(q, 'user');
    const thinking = addMsg('⏳ Thinking...', 'bot thinking');

    try {
      const ctx = getContext();
      const systemPrompt = `You are the Balaji NextGen ERP AI Assistant for ${ctx.company}.
Current page: ${ctx.page}. User role: ${ctx.role}.
You help with: sales reports, inventory queries, GST filing, Tally XML export, WhatsApp sending, KOT management, billing, HR, and all ERP operations.
For data queries, provide helpful summaries. For Tally export, tell user to click the Tally button in the page. For WhatsApp, guide them to the share button.
Keep responses concise, practical, and in plain text (no markdown). Max 3 sentences unless a list is needed.`;

      // Use GAS backend to call AI (avoids CORS and keeps API key server-side)
      let reply = '';
      
      if (typeof erpCoreApi !== 'undefined') {
        try {
          const res = await erpCoreApi({
            action: 'AI_QUERY',
            query: q,
            page: ctx.page,
            role: ctx.role,
            company: ctx.company,
          });
          if (res.ok && res.reply) {
            reply = res.reply;
          }
        } catch(e) {}
      }

      // Fallback: smart local responses
      if (!reply) {
        reply = getSmartReply(q, ctx);
      }

      thinking.remove();
      addMsg(reply, 'bot');

    } catch(e) {
      thinking.remove();
      addMsg('Sorry, I encountered an error. Please try again.', 'bot');
    }
  };

  // Smart local fallback responses
  function getSmartReply(q, ctx) {
    const ql = q.toLowerCase();
    if (ql.includes('tally') || ql.includes('export xml')) {
      return '🧮 To export to Tally: Go to Sales Invoice page → click "Export to Tally" button → a .xml file downloads → import it in Tally Prime via Gateway → Import Data → Vouchers.';
    }
    if (ql.includes('whatsapp') || ql.includes('send invoice')) {
      return '💬 To send via WhatsApp: Open the invoice → click the WhatsApp button → it opens WhatsApp Web with the invoice details pre-filled. For bulk sending, configure WATI API in Settings.';
    }
    if (ql.includes('gst') || ql.includes('gstr')) {
      return '📋 GST Reports: Go to Dashboard → GST Center → select GSTR-1, GSTR-3B or HSN Summary → choose the period → click Download Excel. For filing, use the GST portal with the exported data.';
    }
    if (ql.includes('stock') || ql.includes('inventory') || ql.includes('low stock')) {
      return '📦 For stock levels: Go to Inventory → Item Master. Items with current stock below reorder level are shown in red. Use Stock Ledger for transaction history. Run GRN for incoming stock.';
    }
    if (ql.includes('kot') || ql.includes('kitchen order')) {
      return '🍽 KOT Management: Open Restaurant Dashboard → KOT section shows live pending orders. Click Confirm to send to kitchen. Chef Dashboard shows the kitchen queue in real-time.';
    }
    if (ql.includes('sales') || ql.includes('revenue') || ql.includes('today')) {
      return '📊 For sales data: Open Dashboard → today\'s sales are shown on the KPI tiles. For detailed reports, go to Sales → Daily Sales Report or use the date filter in Sales Register.';
    }
    if (ql.includes('payroll') || ql.includes('salary')) {
      return '💼 Payroll: Go to HR & Payroll → Employee Master → then Payroll Register. Mark attendance first, then generate monthly payroll. Export to Excel for bank transfer.';
    }
    if (ql.includes('invoice') || ql.includes('bill')) {
      return '🧾 To create invoice: Go to Sales → Sales Invoice → fill customer and item details → choose GST format → Save. You can then Print, Export to PDF, send via WhatsApp, or export to Tally.';
    }
    return `I can help with ${ctx.page} operations. For detailed ERP guidance, please ask a specific question about sales, inventory, GST, Tally, WhatsApp, billing, or any module.`;
  }

  function addMsg(text, type) {
    const msgs = document.getElementById('bnj-msgs');
    const div = document.createElement('div');
    div.className = `bnj-msg bnj-${type.includes('user') ? 'user' : 'bot'}${type.includes('thinking') ? ' thinking' : ''}`;
    div.textContent = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
    return div;
  }

  console.log('✅ Balaji AI Assistant loaded');
})();
